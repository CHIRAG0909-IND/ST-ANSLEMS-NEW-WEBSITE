import Nav from "./components/Nav";
import Hero from "./components/Hero";
import { Academics, Legacy, Principal, StatsBand, Ticker } from "./components/Sections";
import {
  Admissions,
  CampusLife,
  CTABand,
  Footer,
  News,
  Testimonials,
} from "./components/Sections2";

export default function App() {
  return (
    <div className="relative min-h-screen bg-ink-950 font-body text-ivory-100 antialiased">
      {/* cinematic atmosphere */}
      <div className="page-vignette" aria-hidden="true" />
      <div className="film-grain" aria-hidden="true" />

      <Nav />

      <main>
        <Hero />
        <Ticker />
        <Legacy />
        <StatsBand />
        <Principal />
        <Academics />
        <CampusLife />
        <Admissions />
        <News />
        <Testimonials />
        <CTABand />
      </main>

      <Footer />
    </div>
  );
}
