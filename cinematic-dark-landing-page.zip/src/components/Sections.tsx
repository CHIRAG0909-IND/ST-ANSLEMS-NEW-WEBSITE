import type { ReactNode } from "react";
import { useCountUp, useInView } from "../hooks";
import { cn } from "../utils/cn";
import {
  IconArrow,
  IconBook,
  IconCompass,
  IconFlask,
  IconLaurel,
  IconScale,
  Reveal,
  SectionHeading,
} from "./ui";

/* ================================ Ticker ================================ */

const TICKER_ITEMS = [
  "Admissions open — Session 2026–27, Pre-Nursery to Class XI",
  "Registration from November at the school office",
  "Class X CBSE Board results — 100% pass, 27 distinctions",
  "Annual Sports Meet — 18 December, main ground",
  "Founder's Day celebrations — 14 November",
  "Parent–Teacher Meeting — first Saturday of every month",
];

export function Ticker() {
  const doubled = [...TICKER_ITEMS, ...TICKER_ITEMS];
  return (
    <div className="marquee relative z-10 overflow-hidden border-y border-gold-500/20 bg-ink-900/80 py-3.5">
      <div className="marquee-track items-center">
        {doubled.map((item, i) => (
          <span
            key={i}
            className="flex shrink-0 items-center gap-6 pr-6 text-[11px] font-medium uppercase tracking-[0.28em] text-ivory-300"
          >
            <span className="text-gold-500">✦</span>
            {item}
          </span>
        ))}
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-ink-950 to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-ink-950 to-transparent" />
    </div>
  );
}

/* ============================= Ornament ============================= */

export function Ornament({ className }: { className?: string }) {
  return (
    <div className={cn("flex items-center justify-center gap-4 text-gold-600", className)} aria-hidden="true">
      <span className="h-px w-16 bg-gradient-to-r from-transparent to-gold-600/60" />
      <svg viewBox="0 0 16 16" className="h-3 w-3">
        <path d="M8 0l2 6 6 2-6 2-2 6-2-6-6-2 6-2 2-6Z" fill="currentColor" opacity="0.8" />
      </svg>
      <span className="h-px w-16 bg-gradient-to-l from-transparent to-gold-600/60" />
    </div>
  );
}

/* ================================ Legacy ================================ */

const MILESTONES = [
  {
    year: "1987",
    title: "The First Bell",
    text: "Gyan Deep Education Society founds St. Anselm's on Delhi Road with a handful of students, a borrowed building, and an outsized promise.",
  },
  {
    year: "1994",
    title: "Senior Secondary",
    text: "The school grows into Classes XI and XII — its first Science batches arrive, and the board-exam tradition begins.",
  },
  {
    year: "2003",
    title: "A Campus Grows",
    text: "A new academic block rises: the library, the laboratories, and the assembly hall take the shape generations will remember.",
  },
  {
    year: "2014",
    title: "The Digital Turn",
    text: "Smart classrooms and activity-based learning reach every wing — from the phonics room to the physics lab.",
  },
  {
    year: "Today",
    title: "1,800 Strong",
    text: "A family of learners from Pre-Nursery to Class XII, drawn from across Alwar — still guided by the same first promise.",
  },
];

export function Legacy() {
  return (
    <section id="legacy" className="relative overflow-hidden py-24 sm:py-32">
      <div className="beam right-[-160px] top-24 h-[420px] w-[420px]" />
      <div className="mx-auto grid max-w-7xl gap-16 px-5 sm:px-6 lg:grid-cols-[1fr_1.05fr] lg:gap-20">
        {/* sticky column */}
        <div className="lg:sticky lg:top-28 lg:self-start">
          <SectionHeading eyebrow="Our Legacy" title="Thirty-seven years of" accent="quiet excellence.">
            Since 1987, St. Anselm&rsquo;s has stood on Delhi Road as Alwar&rsquo;s patient
            builder of minds — an English-medium, co-educational CBSE school where value-based
            education and academic rigour walk hand in hand.
          </SectionHeading>

          <Reveal delay={200} className="mt-10">
            <figure className="frame-ticks relative">
              <div className="overflow-hidden">
                <img
                  src="images/classroom.jpg"
                  alt="Students in a classroom at St. Anselm's"
                  className="aspect-[4/3] w-full object-cover transition-transform duration-[1.8s] ease-out hover:scale-105"
                />
              </div>
              <figcaption className="absolute bottom-0 left-0 bg-ink-950/85 px-5 py-3 text-[10px] font-medium uppercase tracking-[0.3em] text-gold-300 backdrop-blur-sm">
                The morning hour · Senior Wing
              </figcaption>
            </figure>
          </Reveal>

          <Reveal delay={320} className="mt-10 flex items-center gap-5">
            <IconLaurel className="w-16 shrink-0 text-gold-500" />
            <p className="font-display text-lg italic leading-snug text-ivory-300">
              &ldquo;The mind is not a vessel to be filled, but a fire to be kindled.&rdquo;
              <span className="mt-1 block font-body text-[10px] not-italic uppercase tracking-[0.3em] text-ivory-700">
                — Plutarch, our guiding spirit
              </span>
            </p>
          </Reveal>
        </div>

        {/* timeline */}
        <div className="relative">
          <span className="absolute bottom-4 left-[7px] top-2 w-px bg-gradient-to-b from-gold-500/60 via-ink-700 to-transparent" aria-hidden="true" />
          <ol className="space-y-14">
            {MILESTONES.map((m, i) => (
              <Reveal as="li" key={m.year} delay={i * 90} className="relative pl-12">
                <span className="absolute left-0 top-2 flex h-[15px] w-[15px] items-center justify-center">
                  <span className="absolute h-full w-full rotate-45 border border-gold-500/70 bg-ink-950" />
                  <span className="h-[5px] w-[5px] rotate-45 bg-gold-400" />
                </span>
                <p className="font-display text-5xl font-medium leading-none text-gold-400/90">
                  {m.year}
                </p>
                <h3 className="mt-3 text-[13px] font-semibold uppercase tracking-[0.26em] text-ivory-100">
                  {m.title}
                </h3>
                <p className="mt-2.5 max-w-md text-[14.5px] font-light leading-relaxed text-ivory-500">
                  {m.text}
                </p>
              </Reveal>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}

/* ============================== Stats band ============================== */

function Stat({
  value,
  suffix,
  label,
  note,
  start,
}: {
  value: number;
  suffix?: string;
  label: string;
  note: string;
  start: boolean;
}) {
  const n = useCountUp(value, start);
  return (
    <div className="group relative px-6 py-10 text-center transition-colors duration-500 hover:bg-ink-900/60 sm:py-14">
      <p className="font-display text-5xl font-medium text-ivory-50 transition-colors duration-500 group-hover:text-gold-300 sm:text-6xl">
        {n.toLocaleString("en-IN")}
        <span className="text-gold-400">{suffix}</span>
      </p>
      <p className="mt-3 text-[11px] font-semibold uppercase tracking-[0.3em] text-gold-500">
        {label}
      </p>
      <p className="mt-1.5 text-[12.5px] font-light text-ivory-700">{note}</p>
    </div>
  );
}

export function StatsBand() {
  const [ref, inView] = useInView({ threshold: 0.3 });
  return (
    <section className="relative border-y border-gold-500/15 bg-ink-900/40">
      <div
        ref={ref}
        className="mx-auto grid max-w-7xl grid-cols-2 divide-x divide-ivory-100/5 lg:grid-cols-4"
      >
        <Stat value={37} suffix="+" label="Years of Legacy" note="Founded 1987, Delhi Road" start={inView} />
        <Stat value={1839} label="Students" note="Pre-Nursery to Class XII" start={inView} />
        <Stat value={62} label="Classrooms" note="Across four wings" start={inView} />
        <Stat value={100} suffix="%" label="Board Results" note="Class X, year on year" start={inView} />
      </div>
    </section>
  );
}

/* =============================== Principal =============================== */

export function Principal() {
  return (
    <section id="principal" className="relative overflow-hidden py-24 sm:py-32">
      <div className="beam left-[-140px] bottom-10 h-[380px] w-[380px]" />
      <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-6 lg:grid-cols-[0.85fr_1.15fr] lg:gap-20">
        <Reveal variant="left" className="relative mx-auto w-full max-w-sm">
          <div className="frame-ticks relative">
            <img
              src="images/principal.jpg"
              alt="Fr. Reneesh Joseph, Principal"
              className="aspect-[3/4] w-full object-cover"
            />
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink-950/95 via-ink-950/60 to-transparent p-6 pt-16">
              <p className="font-display text-2xl font-medium text-ivory-50">Fr. Reneesh Joseph</p>
              <p className="mt-1 text-[10px] font-medium uppercase tracking-[0.32em] text-gold-400">
                Principal
              </p>
            </div>
          </div>
        </Reveal>

        <div>
          <SectionHeading eyebrow="From the Principal's Desk" title="A word of" accent="welcome.">
            It gives me immense pleasure to welcome you to the official home of St. Anselm&rsquo;s
            Senior Secondary School, Alwar.
          </SectionHeading>
          <Reveal delay={200}>
            <blockquote className="relative mt-8 border-l border-gold-500/50 pl-6 font-display text-2xl font-medium italic leading-snug text-ivory-100 sm:text-[1.7rem]">
              &ldquo;Education is much more than the pursuit of academic excellence — it is a
              journey of discovering one&rsquo;s potential, nurturing character, and developing
              the confidence to face an ever-changing world.&rdquo;
            </blockquote>
          </Reveal>
          <Reveal delay={320}>
            <p className="mt-6 max-w-xl text-[14.5px] font-light leading-relaxed text-ivory-500">
              Our mission is to provide a safe, inclusive and stimulating environment where every
              child is encouraged to learn, grow and excel. Inspired by a rich tradition of
              excellence and guided by strong moral and ethical values, we strive to cultivate
              young minds that are intellectually curious, socially responsible, and rooted in the
              finest of Indian values.
            </p>
          </Reveal>
          <Reveal delay={420} className="mt-8 flex items-center gap-5">
            <span className="h-px w-12 bg-gold-500/60" />
            <p className="font-display text-xl italic text-gold-300">Fr. Reneesh Joseph</p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* =============================== Academics =============================== */

type Stream = {
  numeral: string;
  title: string;
  tagline: string;
  subjects: string[];
  icon: ReactNode;
  featured?: boolean;
};

const STREAMS: Stream[] = [
  {
    numeral: "I",
    title: "Science",
    tagline: "PCM & PCB — the senior wing's flagship stream, taught in fully equipped laboratories.",
    subjects: ["Physics", "Chemistry", "Mathematics", "Biology", "Computer Sc.", "English"],
    icon: <IconFlask className="h-6 w-6" />,
    featured: true,
  },
  {
    numeral: "II",
    title: "Commerce",
    tagline: "Numbers, markets and enterprise — a foundation for CA, CS and business.",
    subjects: ["Accountancy", "Business Studies", "Economics", "Mathematics / IP"],
    icon: <IconScale className="h-6 w-6" />,
  },
  {
    numeral: "III",
    title: "Humanities",
    tagline: "History, society and the human mind — for future lawyers, writers and civil servants.",
    subjects: ["History", "Political Sc.", "Geography", "Psychology", "Fine Arts"],
    icon: <IconCompass className="h-6 w-6" />,
  },
  {
    numeral: "IV",
    title: "Primary & Middle Wing",
    tagline: "Pre-Nursery to VIII — phonics, activity rooms and joyful NCERT-based foundations.",
    subjects: ["Phonics", "EVS", "Art & Craft", "Music", "Computers"],
    icon: <IconBook className="h-6 w-6" />,
  },
];

const STAGES = [
  { name: "Pre-Primary", range: "Pre-Nursery — HKG", color: "text-gold-300" },
  { name: "Primary", range: "Classes I — V", color: "text-gold-300" },
  { name: "Middle", range: "Classes VI — VIII", color: "text-gold-300" },
  { name: "Secondary", range: "Classes IX — X", color: "text-gold-300" },
  { name: "Senior Secondary", range: "Classes XI — XII", color: "text-gold-300" },
];

export function Academics() {
  return (
    <section id="academics" className="relative border-t border-ivory-100/5 bg-ink-900/30 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-8">
          <SectionHeading eyebrow="Academics" title="One school," accent="five journeys.">
            From the first rhyme in Pre-Nursery to the last practical in Class XII, every stage is
            mapped with care — NCERT-rooted, CBSE-assessed, and taught with patience.
          </SectionHeading>
          <Reveal delay={200}>
            <a
              href="#admissions"
              className="group mb-1 inline-flex items-center gap-3 text-[11px] font-semibold uppercase tracking-[0.26em] text-gold-400 transition-colors hover:text-gold-300"
            >
              Seek a seat
              <IconArrow className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1.5" />
            </a>
          </Reveal>
        </div>

        {/* stages strip */}
        <Reveal delay={150} className="mt-14">
          <div className="grid grid-cols-2 gap-px border border-ivory-100/8 bg-ivory-100/8 sm:grid-cols-3 lg:grid-cols-5">
            {STAGES.map((s, i) => (
              <div
                key={s.name}
                className="group bg-ink-950 px-5 py-5 transition-colors duration-500 hover:bg-ink-800"
              >
                <p className="font-display text-2xl italic text-ivory-700 transition-colors duration-500 group-hover:text-gold-400">
                  {String(i + 1).padStart(2, "0")}
                </p>
                <p className="mt-1.5 text-[12px] font-semibold uppercase tracking-[0.18em] text-ivory-100">
                  {s.name}
                </p>
                <p className="mt-0.5 text-[11px] font-light text-ivory-700">{s.range}</p>
              </div>
            ))}
          </div>
        </Reveal>

        {/* streams */}
        <div className="mt-6 grid gap-6 lg:grid-cols-2">
          {STREAMS.map((s, i) => (
            <Reveal
              key={s.title}
              delay={i * 110}
              className={cn(s.featured && "lg:row-span-2")}
            >
              <article
                className={cn(
                  "group relative flex h-full flex-col overflow-hidden border border-ivory-100/10 bg-ink-900/60 transition-all duration-500 hover:border-gold-500/40 hover:bg-ink-800/70",
                )}
              >
                {s.featured && (
                  <div className="relative h-56 overflow-hidden">
                    <img
                      src="images/lab.jpg"
                      alt="Students in the science laboratory"
                      className="h-full w-full object-cover transition-transform duration-[1.6s] ease-out group-hover:scale-108"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink-900 via-ink-950/20 to-transparent" />
                    <span className="absolute left-5 top-5 border border-gold-400/60 bg-ink-950/70 px-3 py-1.5 text-[9.5px] font-semibold uppercase tracking-[0.3em] text-gold-300 backdrop-blur-sm">
                      Flagship Stream
                    </span>
                  </div>
                )}
                <div className={cn("flex flex-1 flex-col p-7", s.featured && "p-8")}>
                  <div className="flex items-start justify-between">
                    <span className="font-display text-4xl italic leading-none text-gold-500/70 transition-colors duration-500 group-hover:text-gold-400">
                      {s.numeral}
                    </span>
                    <span className="flex h-11 w-11 items-center justify-center border border-ivory-100/12 text-gold-400 transition-all duration-500 group-hover:border-gold-500/50 group-hover:bg-gold-500/10">
                      {s.icon}
                    </span>
                  </div>
                  <h3 className="mt-4 font-display text-3xl font-medium text-ivory-50">
                    {s.title}
                  </h3>
                  <p className="mt-2.5 flex-1 text-[13.5px] font-light leading-relaxed text-ivory-500">
                    {s.tagline}
                  </p>
                  <ul className="mt-5 flex flex-wrap gap-2">
                    {s.subjects.map((sub) => (
                      <li
                        key={sub}
                        className="border border-ivory-100/10 px-2.5 py-1 text-[10px] font-medium uppercase tracking-[0.14em] text-ivory-300 transition-colors duration-300 hover:border-gold-500/40 hover:text-gold-300"
                      >
                        {sub}
                      </li>
                    ))}
                  </ul>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
