import { useEffect, useState, type CSSProperties } from "react";
import { useScramble } from "../hooks";
import { cn } from "../utils/cn";
import { IconArrow, IconTorch } from "./ui";

function RotatingSeal() {
  return (
    <div className="relative h-32 w-32 sm:h-36 sm:w-36">
      <svg viewBox="0 0 120 120" className="spin-slow absolute inset-0 h-full w-full text-gold-400">
        <defs>
          <path id="sealcircle" d="M60,60 m-46,0 a46,46 0 1,1 92,0 a46,46 0 1,1 -92,0" />
        </defs>
        <text className="fill-current text-[9.2px] font-medium uppercase" style={{ letterSpacing: "0.32em" }}>
          <textPath href="#sealcircle">
            Admissions Open · Session 2026–27 · CBSE ·
          </textPath>
        </text>
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full border border-gold-500/40 bg-ink-950/70">
          <IconTorch className="flicker h-6 w-6 text-gold-300" />
        </div>
      </div>
    </div>
  );
}

export default function Hero() {
  const [loaded, setLoaded] = useState(false);
  const eyebrow = useScramble("GYAN DEEP EDUCATION SOCIETY · EST. 1987", loaded, 22);

  useEffect(() => {
    const t = window.setTimeout(() => setLoaded(true), 200);
    return () => window.clearTimeout(t);
  }, []);

  const line = (d: number) => ({ "--d": `${d}ms` } as CSSProperties);

  return (
    <section id="top" className="relative flex min-h-[100svh] flex-col overflow-hidden">
      {/* backdrop */}
      <div className="absolute inset-0">
        <img
          src="images/hero.jpg"
          alt="St. Anselm's school campus at dusk"
          className="kenburns h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950/95 via-ink-950/55 to-ink-950/25" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-transparent to-ink-950/70" />
        <div className="beam -left-24 top-1/3 h-[480px] w-[480px]" />
      </div>

      {/* right vertical rail */}
      <div className="pointer-events-none absolute right-5 top-1/2 z-10 hidden -translate-y-1/2 items-center gap-4 lg:flex [writing-mode:vertical-rl]">
        <span className="text-[10px] font-medium uppercase tracking-[0.5em] text-ivory-500">
          Est · 1987 · Delhi Road · Alwar
        </span>
        <span className="h-24 w-px bg-gradient-to-b from-gold-500/70 to-transparent" />
      </div>

      {/* content */}
      <div
        className={cn(
          "relative z-10 mx-auto flex w-full max-w-7xl flex-1 flex-col justify-end px-5 pb-10 pt-40 sm:px-6",
          loaded && "hero-loaded",
        )}
      >
        <p className="mb-6 h-4 font-body text-[10.5px] font-medium uppercase tracking-[0.44em] text-gold-400 sm:text-[11px]">
          {eyebrow}
        </p>

        <h1 className="font-display font-medium leading-[0.98] text-ivory-50">
          <span className="mask-line text-[13.5vw] sm:text-7xl lg:text-[6.2rem]">
            <span style={line(150)}>Where young minds</span>
          </span>
          <span className="mask-line text-[13.5vw] sm:text-7xl lg:text-[6.2rem]">
            <span style={line(300)}>
              catch <em className="italic text-gold-300">fire</em> —
            </span>
          </span>
          <span className="mask-line text-[13.5vw] sm:text-7xl lg:text-[6.2rem]">
            <span style={line(450)}>and character endures.</span>
          </span>
        </h1>

        <div
          className={cn(
            "mt-8 max-w-xl transition-all delay-[900ms] duration-1000",
            loaded ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0",
          )}
        >
          <p className="text-[15px] font-light leading-relaxed text-ivory-300 sm:text-base">
            St. Anselm&rsquo;s Senior Secondary School — a CBSE institution on Delhi Road, Alwar,
            nurturing scholars of intellect, faith and heart from Pre-Nursery to Class XII since
            1987.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <a
              href="#admissions"
              className="btn-sheen group inline-flex items-center gap-3 bg-gold-500 px-7 py-4 text-[11.5px] font-semibold uppercase tracking-[0.24em] text-ink-950 transition-colors duration-300 hover:bg-gold-400"
            >
              Apply for 2026–27
              <IconArrow className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </a>
            <a
              href="#campus"
              className="group inline-flex items-center gap-3 border border-ivory-100/25 px-7 py-4 text-[11.5px] font-semibold uppercase tracking-[0.24em] text-ivory-100 transition-all duration-300 hover:border-gold-400 hover:text-gold-300"
            >
              Walk the Campus
              <span className="inline-block h-1 w-1 rounded-full bg-gold-400 transition-transform duration-300 group-hover:scale-150" />
            </a>
          </div>

          {/* quick facts */}
          <div className="mt-10 flex flex-wrap items-center gap-x-7 gap-y-3 border-t border-ivory-100/10 pt-6 text-[10.5px] font-medium uppercase tracking-[0.26em] text-ivory-500">
            {["CBSE Affiliated", "Pre-Nursery — XII", "Science · Commerce · Arts", "Day cum Residential"].map(
              (f) => (
                <span key={f} className="flex items-center gap-7">
                  <span className="transition-colors hover:text-gold-300">{f}</span>
                  <span className="text-gold-600">◆</span>
                </span>
              ),
            )}
          </div>
        </div>
      </div>

      {/* bottom bar */}
      <div
        className={cn(
          "relative z-10 mx-auto flex w-full max-w-7xl items-end justify-between px-5 pb-8 sm:px-6 transition-opacity delay-[1200ms] duration-1000",
          loaded ? "opacity-100" : "opacity-0",
        )}
      >
        <a href="#legacy" className="group flex items-center gap-4" aria-label="Scroll to legacy">
          <span className="scroll-cue relative block h-14 w-px overflow-hidden bg-ivory-100/15" />
          <span className="text-[10px] font-medium uppercase tracking-[0.34em] text-ivory-500 transition-colors group-hover:text-gold-300">
            Scroll — Our Story
          </span>
        </a>
        <div className="hidden sm:block">
          <RotatingSeal />
        </div>
        <p className="hidden text-right font-body text-[10px] uppercase tracking-[0.3em] leading-relaxed text-ivory-700 md:block">
          27.5631° N · 76.6117° E
          <br />
          <span className="text-ivory-500">Alwar, Rajasthan</span>
        </p>
      </div>
    </section>
  );
}
