import { useEffect, useState } from "react";
import { useScrollY } from "../hooks";
import { cn } from "../utils/cn";
import { Crest, IconPhone } from "./ui";

const LINKS = [
  { label: "Legacy", href: "#legacy" },
  { label: "Principal", href: "#principal" },
  { label: "Academics", href: "#academics" },
  { label: "Campus Life", href: "#campus" },
  { label: "Admissions", href: "#admissions" },
  { label: "News", href: "#news" },
  { label: "Contact", href: "#contact" },
];

export default function Nav() {
  const y = useScrollY();
  const scrolled = y > 48;
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <>
      {/* Top ribbon */}
      <div className="fixed inset-x-0 top-0 z-[60] hidden border-b border-gold-500/15 bg-ink-950/85 backdrop-blur-sm md:block">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.28em] text-ivory-500">
          <p>
            CBSE Affiliated <span className="mx-2 text-gold-500">◆</span> Gyan Deep Education
            Society
          </p>
          <div className="flex items-center gap-6">
            <a
              href="tel:+911442372479"
              className="flex items-center gap-2 transition-colors hover:text-gold-300"
            >
              <IconPhone className="h-3 w-3" /> 0144-2372479
            </a>
            <span className="flex items-center gap-2 text-gold-300">
              <span className="relative flex h-1.5 w-1.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-gold-400 opacity-70" />
                <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-gold-400" />
              </span>
              Admissions Open 2026–27
            </span>
          </div>
        </div>
      </div>

      {/* Main nav */}
      <header
        className={cn(
          "fixed inset-x-0 z-50 transition-all duration-500 md:top-[30px] top-0",
          scrolled
            ? "border-b border-gold-500/15 bg-ink-950/92 shadow-[0_18px_50px_-20px_rgba(0,0,0,0.9)] backdrop-blur-md md:top-0"
            : "bg-transparent",
        )}
      >
        <div
          className={cn(
            "mx-auto flex max-w-7xl items-center justify-between px-5 transition-all duration-500 sm:px-6",
            scrolled ? "py-3" : "py-5",
          )}
        >
          <a href="#top" className="group flex items-center gap-3.5">
            <Crest className="h-11 w-10 text-gold-400 transition-transform duration-500 group-hover:scale-105" />
            <span className="leading-none">
              <span className="block font-display text-[1.45rem] font-semibold tracking-wide text-ivory-50">
                St. Anselm&rsquo;s
              </span>
              <span className="mt-1 block text-[9px] font-medium uppercase tracking-[0.34em] text-gold-500">
                Sr. Sec. School · Alwar
              </span>
            </span>
          </a>

          <nav className="hidden items-center gap-7 lg:flex">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="link-sweep text-[11.5px] font-medium uppercase tracking-[0.22em] text-ivory-300 transition-colors hover:text-ivory-50"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <a
              href="#admissions"
              className="btn-sheen hidden items-center gap-2 border border-gold-500/70 bg-gold-500/10 px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.24em] text-gold-300 transition-all duration-300 hover:bg-gold-500 hover:text-ink-950 sm:inline-flex"
            >
              Apply Now
            </a>
            <button
              onClick={() => setOpen(!open)}
              aria-label="Toggle menu"
              className="relative flex h-11 w-11 items-center justify-center border border-ivory-100/15 text-ivory-100 lg:hidden"
            >
              <span
                className={cn(
                  "absolute h-px w-5 bg-current transition-all duration-300",
                  open ? "rotate-45" : "-translate-y-[5px]",
                )}
              />
              <span
                className={cn(
                  "absolute h-px w-5 bg-current transition-all duration-300",
                  open ? "-rotate-45" : "translate-y-[5px]",
                )}
              />
            </button>
          </div>
        </div>
      </header>

      {/* Mobile overlay menu */}
      <div
        className={cn(
          "fixed inset-0 z-40 flex flex-col justify-center bg-ink-950/97 px-8 backdrop-blur-lg transition-all duration-500 lg:hidden",
          open ? "pointer-events-auto opacity-100" : "pointer-events-none opacity-0",
        )}
      >
        <div className="pointer-events-none absolute inset-0 opacity-40">
          <div className="beam left-1/4 top-1/4 h-96 w-96 -translate-x-1/2" />
        </div>
        <nav className="relative space-y-1">
          {LINKS.map((l, i) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setOpen(false)}
              className={cn(
                "group flex items-baseline gap-4 py-2 transition-all duration-500",
                open ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0",
              )}
              style={{ transitionDelay: open ? `${120 + i * 60}ms` : "0ms" }}
            >
              <span className="font-display text-sm italic text-gold-500">
                {String(i + 1).padStart(2, "0")}
              </span>
              <span className="font-display text-4xl font-medium text-ivory-100 transition-colors group-hover:text-gold-300">
                {l.label}
              </span>
            </a>
          ))}
        </nav>
        <p className="relative mt-10 text-[10px] uppercase tracking-[0.3em] text-ivory-700">
          Delhi Road, Alwar — Est. 1987
        </p>
      </div>
    </>
  );
}
