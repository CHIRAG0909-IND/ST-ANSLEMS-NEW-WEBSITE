import type { CSSProperties, ReactNode, SVGProps } from "react";
import { useInView } from "../hooks";
import { cn } from "../utils/cn";

/* ---------------------------------- Crest ---------------------------------- */

export function Crest({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 72" fill="none" className={className} aria-hidden="true">
      <path
        d="M32 2 58 10v26c0 16-11 27-26 34C17 63 6 52 6 36V10L32 2Z"
        stroke="currentColor"
        strokeWidth="1.6"
      />
      <path
        d="M32 8 52 14.5V36c0 12.6-8.6 21.8-20 27.6C20.6 57.8 12 48.6 12 36V14.5L32 8Z"
        stroke="currentColor"
        strokeWidth="0.8"
        opacity="0.55"
      />
      {/* open book */}
      <path
        d="M32 34c-4.5-2.6-9.5-3.2-14-2.4v15.6c4.5-.8 9.5-.2 14 2.4 4.5-2.6 9.5-3.2 14-2.4V31.6c-4.5-.8-9.5-.2-14 2.4Z"
        stroke="currentColor"
        strokeWidth="1.4"
      />
      <path d="M32 34v15.6" stroke="currentColor" strokeWidth="1.1" />
      {/* flame above the book */}
      <path
        d="M32 14c2.6 3 4.4 5.2 4.4 8a4.4 4.4 0 0 1-8.8 0c0-2.8 1.8-5 4.4-8Z"
        stroke="currentColor"
        strokeWidth="1.4"
      />
      <path d="M32 20.2c1 1.2 1.7 2 1.7 3.1a1.7 1.7 0 1 1-3.4 0c0-1.1.7-1.9 1.7-3.1Z" fill="currentColor" opacity="0.85" />
      {/* stars */}
      <path d="M19 22.5l.9 1.9 1.9.9-1.9.9-.9 1.9-.9-1.9-1.9-.9 1.9-.9.9-1.9Z" fill="currentColor" opacity="0.8" />
      <path d="M45 22.5l.9 1.9 1.9.9-1.9.9-.9 1.9-.9-1.9-1.9-.9 1.9-.9.9-1.9Z" fill="currentColor" opacity="0.8" />
    </svg>
  );
}

/* --------------------------------- Reveal --------------------------------- */

export function Reveal({
  children,
  className,
  delay = 0,
  variant,
  as: Tag = "div",
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
  variant?: "left" | "right" | "scale";
  as?: "div" | "section" | "article" | "li" | "figure" | "span";
}) {
  const [ref, inView] = useInView();
  return (
    <Tag
      ref={ref as never}
      className={cn(
        "reveal",
        variant === "left" && "reveal-left",
        variant === "right" && "reveal-right",
        variant === "scale" && "reveal-scale",
        inView && "is-in",
        className,
      )}
      style={{ "--d": `${delay}ms` } as CSSProperties}
    >
      {children}
    </Tag>
  );
}

/* ----------------------------- Section heading ---------------------------- */

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <p
      className={cn(
        "flex items-center gap-3 font-body text-[11px] font-medium uppercase tracking-[0.42em] text-gold-400",
        className,
      )}
    >
      <span className="inline-block h-px w-10 bg-gold-500/70" aria-hidden="true" />
      {children}
    </p>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  accent,
  children,
  align = "left",
  className,
}: {
  eyebrow: string;
  title: string;
  accent?: string;
  children?: ReactNode;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div className={cn("max-w-2xl", align === "center" && "mx-auto text-center", className)}>
      <Reveal>
        <Eyebrow className={cn(align === "center" && "justify-center")}>{eyebrow}</Eyebrow>
      </Reveal>
      <Reveal delay={120}>
        <h2 className="mt-5 font-display text-4xl font-medium leading-[1.05] text-ivory-50 sm:text-5xl lg:text-[3.4rem]">
          {title}{" "}
          {accent && <em className="font-medium italic text-gold-300">{accent}</em>}
        </h2>
      </Reveal>
      {children && (
        <Reveal delay={240}>
          <p className="mt-5 text-[15px] font-light leading-relaxed text-ivory-500">{children}</p>
        </Reveal>
      )}
    </div>
  );
}

/* ---------------------------------- Icons --------------------------------- */

type IconProps = SVGProps<SVGSVGElement>;

const base = (p: IconProps) => ({
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.4,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  viewBox: "0 0 24 24",
  ...p,
});

export const IconTorch = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M12 3c1.9 2.2 3.2 3.9 3.2 5.9a3.2 3.2 0 1 1-6.4 0C8.8 6.9 10.1 5.2 12 3Z" />
    <path d="M12 7.4c.7.9 1.2 1.5 1.2 2.3a1.2 1.2 0 1 1-2.4 0c0-.8.5-1.4 1.2-2.3Z" fill="currentColor" stroke="none" opacity="0.8" />
    <path d="M9.5 13.5h5l-.7 3h-3.6l-.7-3Z" />
    <path d="M11 16.5 10.4 21h3.2l-.6-4.5" />
  </svg>
);

export const IconBook = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M12 6.5C10 5.2 7.4 4.8 5 5.3v13c2.4-.5 5-.1 7 1.2 2-1.3 4.6-1.7 7-1.2v-13c-2.4-.5-5-.1-7 1.2Z" />
    <path d="M12 6.5v13" />
    <path d="M7.5 9.2c1.2-.1 2.4.1 3.4.6M7.5 12.2c1.2-.1 2.4.1 3.4.6M13.1 9.8c1-.5 2.2-.7 3.4-.6M13.1 12.8c1-.5 2.2-.7 3.4-.6" opacity="0.7" />
  </svg>
);

export const IconFlask = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M10 3.5h4M10.7 3.5v5L5.8 17a2.2 2.2 0 0 0 2 3.2h8.4a2.2 2.2 0 0 0 2-3.2l-4.9-8.5v-5" />
    <path d="M7.6 14.5h8.8" />
    <circle cx="10.5" cy="17.2" r="0.7" fill="currentColor" stroke="none" />
    <circle cx="13.6" cy="16.4" r="0.5" fill="currentColor" stroke="none" />
  </svg>
);

export const IconCompass = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="m15.2 8.8-1.9 4.5-4.5 1.9 1.9-4.5 4.5-1.9Z" />
    <circle cx="12" cy="12" r="0.7" fill="currentColor" stroke="none" />
  </svg>
);

export const IconScale = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M12 4v16M8 20h8M12 4c-2.2 1.2-4.6 1.6-7 1.4L7 11a2.6 2.6 0 0 0 5 0L14 5.4" opacity="0" />
    <path d="M12 4.5v15M8.5 19.5h7" />
    <path d="M5.5 6.5h13M5.5 6.5 3.5 12a2.7 2.7 0 0 0 4 0l-2-5.5ZM18.5 6.5l-2 5.5a2.7 2.7 0 0 0 4 0l-2-5.5Z" />
  </svg>
);

export const IconMusic = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M9 18.5V6.2l10-2v12.1" />
    <circle cx="6.8" cy="18.6" r="2.2" />
    <circle cx="16.8" cy="16.4" r="2.2" />
  </svg>
);

export const IconTrophy = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M8 4.5h8v6a4 4 0 0 1-8 0v-6Z" />
    <path d="M8 6H4.8c0 3 1.3 4.7 3.2 5M16 6h3.2c0 3-1.3 4.7-3.2 5" />
    <path d="M12 14.5v3M8.5 20.5h7M10 17.5h4" />
  </svg>
);

export const IconCheck = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="m4.5 12.5 5 5L19.5 6.5" />
  </svg>
);

export const IconArrow = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M4 12h16M13.5 5.5 20 12l-6.5 6.5" />
  </svg>
);

export const IconPhone = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M5.5 4.5h3.4l1.5 4-2.2 1.7a12.5 12.5 0 0 0 5.6 5.6l1.7-2.2 4 1.5v3.4c0 .8-.7 1.5-1.5 1.5C10 20 4 14 4 6c0-.8.7-1.5 1.5-1.5Z" />
  </svg>
);

export const IconMail = (p: IconProps) => (
  <svg {...base(p)}>
    <rect x="3.5" y="5.5" width="17" height="13" rx="1.5" />
    <path d="m4.5 7.5 7.5 6 7.5-6" />
  </svg>
);

export const IconPin = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M12 21s-6.8-6.2-6.8-11A6.8 6.8 0 0 1 12 3.2 6.8 6.8 0 0 1 18.8 10c0 4.8-6.8 11-6.8 11Z" />
    <circle cx="12" cy="10" r="2.4" />
  </svg>
);

export const IconClock = (p: IconProps) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7v5.2l3.4 2" />
  </svg>
);

export const IconBell = (p: IconProps) => (
  <svg {...base(p)}>
    <path d="M12 4a5.5 5.5 0 0 1 5.5 5.5c0 4 1 5.5 2 6.5H4.5c1-1 2-2.5 2-6.5A5.5 5.5 0 0 1 12 4Z" />
    <path d="M10 19a2 2 0 0 0 4 0" />
  </svg>
);

export const IconLaurel = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 48 24" fill="none" className={className} aria-hidden="true">
    <path
      d="M2 4c4 8 12 14 22 16M46 4c-4 8-12 14-22 16"
      stroke="currentColor"
      strokeWidth="1.2"
      strokeLinecap="round"
    />
    <path
      d="M6 9.5c2.4.4 4 1.8 5 3.9-2.4-.4-4-1.8-5-3.9ZM12 13.7c2.4.2 4.2 1.4 5.4 3.4-2.4-.2-4.2-1.4-5.4-3.4ZM42 9.5c-2.4.4-4 1.8-5 3.9 2.4-.4 4-1.8 5-3.9ZM36 13.7c-2.4.2-4.2 1.4-5.4 3.4 2.4-.2 4.2-1.4 5.4-3.4Z"
      fill="currentColor"
      opacity="0.8"
    />
  </svg>
);
