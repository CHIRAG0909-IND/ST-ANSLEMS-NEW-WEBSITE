import { useState, type FormEvent } from "react";
import { cn } from "../utils/cn";
import {
  Crest,
  IconArrow,
  IconBell,
  IconBook,
  IconCheck,
  IconClock,
  IconFlask,
  IconMail,
  IconMusic,
  IconPhone,
  IconPin,
  IconTrophy,
  Reveal,
  SectionHeading,
} from "./ui";
import { Ornament } from "./Sections";

/* =============================== Campus Life =============================== */

const CAMPUS = [
  {
    img: "images/library.jpg",
    title: "The Library",
    text: "Two reading halls, ten thousand books, and the quietest hour of the day.",
    tag: "Reading",
    icon: <IconBook className="h-4 w-4" />,
    span: "sm:col-span-2",
  },
  {
    img: "images/sports.jpg",
    title: "The Big Ground",
    text: "Cricket, athletics and kho-kho under an Alwar dusk.",
    tag: "Sports",
    icon: <IconTrophy className="h-4 w-4" />,
    span: "",
  },
  {
    img: "images/arts.jpg",
    title: "Music & Fine Arts",
    text: "Sitar, tabla and choir — the rooms that never sit silent.",
    tag: "Arts",
    icon: <IconMusic className="h-4 w-4" />,
    span: "",
  },
  {
    img: "images/assembly.jpg",
    title: "Morning Assembly",
    text: "The day begins as it has since 1987 — together, in song and thought.",
    tag: "Tradition",
    icon: <IconBell className="h-4 w-4" />,
    span: "sm:col-span-2",
  },
];

const DAY = [
  { time: "07:40", label: "Morning assembly & hymn" },
  { time: "08:00", label: "First period begins" },
  { time: "11:10", label: "Recess in the courtyard" },
  { time: "12:30", label: "Labs, library & studios" },
  { time: "14:00", label: "Sports, clubs & NCC" },
  { time: "15:30", label: "The last bell" },
];

export function CampusLife() {
  return (
    <section id="campus" className="relative overflow-hidden py-24 sm:py-32">
      <div className="beam right-[-120px] top-40 h-[400px] w-[400px]" />
      <div className="mx-auto max-w-7xl px-5 sm:px-6">
        <SectionHeading eyebrow="Campus Life" title="Six hours that" accent="shape a lifetime." align="center">
          Beyond the syllabus lives the real school — the library hush, the assembly hymn, the
          last-bell rush. This is a day on Delhi Road.
        </SectionHeading>

        {/* mosaic */}
        <div className="mt-16 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {CAMPUS.map((c, i) => (
            <Reveal key={c.title} delay={i * 100} className={cn(c.span)}>
              <figure className="group relative overflow-hidden border border-ivory-100/8">
                <img
                  src={c.img}
                  alt={c.title}
                  className="aspect-[16/10] w-full object-cover transition-transform duration-[1.8s] ease-out group-hover:scale-107"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950/95 via-ink-950/25 to-transparent opacity-80 transition-opacity duration-500 group-hover:opacity-95" />
                <span className="absolute right-4 top-4 flex items-center gap-2 border border-ivory-100/20 bg-ink-950/60 px-2.5 py-1 text-[9px] font-semibold uppercase tracking-[0.26em] text-gold-300 backdrop-blur-sm">
                  {c.icon}
                  {c.tag}
                </span>
                <figcaption className="absolute inset-x-0 bottom-0 p-6">
                  <h3 className="font-display text-2xl font-medium text-ivory-50">{c.title}</h3>
                  <p className="mt-1.5 max-w-md text-[13px] font-light leading-relaxed text-ivory-300 opacity-0 transition-all duration-500 group-hover:opacity-100">
                    {c.text}
                  </p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>

        {/* a day strip */}
        <Reveal delay={150} className="mt-16">
          <div className="border border-ivory-100/8 bg-ink-900/40">
            <div className="flex items-center justify-between border-b border-ivory-100/8 px-6 py-3.5">
              <p className="text-[10px] font-semibold uppercase tracking-[0.34em] text-gold-400">
                A Day at Anselm&rsquo;s
              </p>
              <IconClock className="h-4 w-4 text-ivory-700" />
            </div>
            <ol className="grid grid-cols-2 divide-x divide-ivory-100/5 sm:grid-cols-3 lg:grid-cols-6">
              {DAY.map((d) => (
                <li key={d.time} className="group px-5 py-6 transition-colors duration-500 hover:bg-ink-800/70">
                  <p className="font-display text-2xl font-medium text-gold-400 transition-transform duration-500 group-hover:-translate-y-0.5">
                    {d.time}
                  </p>
                  <p className="mt-1 text-[11.5px] font-light leading-snug text-ivory-500">
                    {d.label}
                  </p>
                </li>
              ))}
            </ol>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ================================ Admissions ================================ */

const STEPS = [
  { n: "01", t: "Enquire & Visit", d: "Collect the prospectus from the school office on Delhi Road, or walk the campus on any working morning." },
  { n: "02", t: "Register & Interact", d: "Submit the registration form. Young children meet our teachers for a gentle, friendly interaction; Class II onwards appears for a short entrance assessment." },
  { n: "03", t: "Document Verification", d: "Present originals for verification — birth certificate, Aadhaar, transfer certificate where applicable. Originals return to you the same day." },
  { n: "04", t: "Confirm the Seat", d: "Complete the fee formalities, receive the almanac and uniform slip — and welcome to the Anselm's family." },
];

const AGE_ROWS = [
  ["Pre-Nursery", "2+ years"],
  ["Nursery", "3+ years"],
  ["LKG", "4+ years"],
  ["HKG", "5+ years"],
  ["Class I", "6+ years"],
  ["Class II – X", "as applicable"],
  ["Class XI", "after Class X Board"],
];

const DOCUMENTS = [
  "Original Birth Certificate (Registrar of Births & Deaths) with one photocopy",
  "Latest passport-size photograph and Aadhaar card copy of the student",
  "Valid photo ID proof of both parents",
  "Transfer Certificate & previous year's Report Card — Class II onwards",
  "Permanent Education Number (PEN) & APAAR ID of the student",
];

export function Admissions() {
  const [sent, setSent] = useState(false);
  const onSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section id="admissions" className="relative border-t border-ivory-100/5 bg-ink-900/30 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-6">
        <div className="grid gap-14 lg:grid-cols-[1.2fr_1fr] lg:gap-20">
          {/* left — steps + form */}
          <div>
            <SectionHeading eyebrow="Admissions 2026–27" title="The gates are" accent="open.">
              Admission is open to all. Registration for the new session begins in November — seats
              are allotted in order of registration, so we suggest an early visit.
            </SectionHeading>

            <ol className="mt-12 space-y-0">
              {STEPS.map((s, i) => (
                <Reveal as="li" key={s.n} delay={i * 100} className="group relative flex gap-6 pb-10 last:pb-0">
                  {i < STEPS.length - 1 && (
                    <span className="absolute left-[26px] top-14 h-[calc(100%-3.5rem)] w-px bg-ivory-100/10" aria-hidden="true" />
                  )}
                  <span className="flex h-[52px] w-[52px] shrink-0 items-center justify-center border border-gold-500/40 bg-ink-950 font-display text-lg italic text-gold-400 transition-all duration-500 group-hover:bg-gold-500 group-hover:text-ink-950">
                    {s.n}
                  </span>
                  <div className="pt-1">
                    <h3 className="text-[13.5px] font-semibold uppercase tracking-[0.22em] text-ivory-100">
                      {s.t}
                    </h3>
                    <p className="mt-2 max-w-lg text-[13.5px] font-light leading-relaxed text-ivory-500">
                      {s.d}
                    </p>
                  </div>
                </Reveal>
              ))}
            </ol>

            {/* prospectus form */}
            <Reveal delay={200} className="mt-12">
              <div className="border border-gold-500/25 bg-ink-950/80 p-7 sm:p-8">
                <p className="font-display text-2xl font-medium text-ivory-50">
                  Request the <em className="italic text-gold-300">prospectus</em>
                </p>
                {sent ? (
                  <div className="mt-5 flex items-start gap-4 border border-gold-500/30 bg-gold-500/10 p-5">
                    <IconCheck className="mt-0.5 h-5 w-5 shrink-0 text-gold-300" />
                    <p className="text-[13.5px] font-light leading-relaxed text-ivory-100">
                      Thank you — your request is noted. The school office will call you within two
                      working days. For anything urgent, ring us on{" "}
                      <span className="text-gold-300">0144-2372479</span>.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={onSubmit} className="mt-5 grid gap-4 sm:grid-cols-2">
                    <label className="block">
                      <span className="mb-1.5 block text-[10px] font-semibold uppercase tracking-[0.26em] text-ivory-700">
                        Parent's name
                      </span>
                      <input
                        required
                        type="text"
                        placeholder="e.g. Rajesh Sharma"
                        className="w-full border border-ivory-100/15 bg-ink-900/70 px-4 py-3 text-sm font-light text-ivory-100 placeholder:text-ivory-700 focus:border-gold-500/60 focus:outline-none"
                      />
                    </label>
                    <label className="block">
                      <span className="mb-1.5 block text-[10px] font-semibold uppercase tracking-[0.26em] text-ivory-700">
                        Phone
                      </span>
                      <input
                        required
                        type="tel"
                        placeholder="10-digit mobile"
                        className="w-full border border-ivory-100/15 bg-ink-900/70 px-4 py-3 text-sm font-light text-ivory-100 placeholder:text-ivory-700 focus:border-gold-500/60 focus:outline-none"
                      />
                    </label>
                    <label className="block sm:col-span-2">
                      <span className="mb-1.5 block text-[10px] font-semibold uppercase tracking-[0.26em] text-ivory-700">
                        Seeking admission to
                      </span>
                      <select className="w-full appearance-none border border-ivory-100/15 bg-ink-900/70 px-4 py-3 text-sm font-light text-ivory-100 focus:border-gold-500/60 focus:outline-none">
                        {["Pre-Nursery", "Nursery / KG", "Class I — V", "Class VI — VIII", "Class IX — X", "Class XI (Science)", "Class XI (Commerce)", "Class XI (Humanities)"].map(
                          (o) => (
                            <option key={o}>{o}</option>
                          ),
                        )}
                      </select>
                    </label>
                    <button
                      type="submit"
                      className="btn-sheen group mt-1 inline-flex items-center justify-center gap-3 bg-gold-500 px-7 py-3.5 text-[11px] font-semibold uppercase tracking-[0.26em] text-ink-950 transition-colors duration-300 hover:bg-gold-400 sm:col-span-2"
                    >
                      Send me the details
                      <IconArrow className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                    </button>
                  </form>
                )}
              </div>
            </Reveal>
          </div>

          {/* right — age + documents */}
          <div className="space-y-8 lg:pt-24">
            <Reveal variant="right">
              <div className="border border-ivory-100/10 bg-ink-950/70">
                <div className="border-b border-ivory-100/10 px-6 py-4">
                  <p className="text-[10px] font-semibold uppercase tracking-[0.32em] text-gold-400">
                    Age Eligibility · as on 31st March
                  </p>
                </div>
                <table className="w-full text-left">
                  <tbody>
                    {AGE_ROWS.map(([cls, age], i) => (
                      <tr
                        key={cls}
                        className={cn(
                          "transition-colors duration-300 hover:bg-ink-800/70",
                          i !== AGE_ROWS.length - 1 && "border-b border-ivory-100/5",
                        )}
                      >
                        <td className="px-6 py-3 text-[13px] font-medium text-ivory-100">{cls}</td>
                        <td className="px-6 py-3 text-right font-display text-lg italic text-gold-300">
                          {age}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Reveal>

            <Reveal variant="right" delay={120}>
              <div className="border border-ivory-100/10 bg-ink-950/70 p-6 sm:p-7">
                <p className="text-[10px] font-semibold uppercase tracking-[0.32em] text-gold-400">
                  Documents to Carry
                </p>
                <ul className="mt-5 space-y-4">
                  {DOCUMENTS.map((d) => (
                    <li key={d} className="flex items-start gap-3.5">
                      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center border border-gold-500/40 text-gold-400">
                        <IconCheck className="h-3 w-3" />
                      </span>
                      <span className="text-[13px] font-light leading-relaxed text-ivory-300">{d}</span>
                    </li>
                  ))}
                </ul>
                <p className="mt-6 border-t border-ivory-100/10 pt-4 text-[11.5px] font-light leading-relaxed text-ivory-700">
                  A one-month prior written notice is required for withdrawal of a student. Transfer
                  Certificates are issued only after all dues stand cleared.
                </p>
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ================================= News ================================= */

const NEWS = [
  {
    day: "18",
    month: "Dec",
    tag: "Event",
    title: "Annual Sports Meet",
    text: "Track finals, cricket and kho-kho on the big ground. Families are welcome from 9:00 a.m.; the Chief Guest arrives at 10:30.",
  },
  {
    day: "14",
    month: "Nov",
    tag: "Celebration",
    title: "Founder's Day",
    text: "A morning of thanksgiving, followed by the inter-house cultural programme — song, skit and speech in honour of our founders.",
  },
  {
    day: "09",
    month: "Jan",
    tag: "Exhibition",
    title: "Science & Art Exhibition",
    text: "Working models, canvases and craft from Classes VI to XII, open to parents through the afternoon.",
  },
];

export function News() {
  return (
    <section id="news" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHeading eyebrow="Notice Board" title="News &" accent="events." />
          <Reveal delay={150}>
            <p className="mb-2 max-w-xs text-[12.5px] font-light leading-relaxed text-ivory-700">
              From the school almanac — dates worth marking on your calendar this session.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-px border border-ivory-100/8 bg-ivory-100/8 md:grid-cols-3">
          {NEWS.map((n, i) => (
            <Reveal key={n.title} delay={i * 120}>
              <article className="group flex h-full flex-col bg-ink-950 p-8 transition-colors duration-500 hover:bg-ink-900">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-display text-6xl font-medium leading-none text-ivory-100 transition-colors duration-500 group-hover:text-gold-300">
                      {n.day}
                    </p>
                    <p className="mt-1 text-[10.5px] font-semibold uppercase tracking-[0.34em] text-gold-500">
                      {n.month} 2026
                    </p>
                  </div>
                  <span className="border border-ivory-100/15 px-2.5 py-1 text-[9px] font-semibold uppercase tracking-[0.26em] text-ivory-500 transition-colors duration-300 group-hover:border-gold-500/40 group-hover:text-gold-300">
                    {n.tag}
                  </span>
                </div>
                <h3 className="mt-6 font-display text-2xl font-medium text-ivory-50">{n.title}</h3>
                <p className="mt-2.5 flex-1 text-[13.5px] font-light leading-relaxed text-ivory-500">
                  {n.text}
                </p>
                <span className="mt-6 block h-px w-full bg-ivory-100/8 transition-all duration-700 group-hover:bg-gold-500/40" />
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* =============================== Testimonials =============================== */

const QUOTES = [
  {
    text: "We chose St. Anselm's for the discipline and stayed for the warmth. My daughter runs to the school gate every single morning — that tells you everything.",
    name: "Mrs. Kavita Sharma",
    role: "Parent · Class IV",
  },
  {
    text: "The values quietly drilled into us at Anselm's — punctuality, honesty, curiosity — still run my day as a doctor, fifteen years later.",
    name: "Dr. Abhishek Mathur",
    role: "Alumnus · Batch of 2008",
  },
  {
    text: "From the assembly hymn to the physics lab, every day here feels like it matters. The teachers know your name and your potential, sometimes before you do.",
    name: "Aarav Singh",
    role: "Student · Class XII, Science",
  },
];

export function Testimonials() {
  return (
    <section className="relative border-t border-ivory-100/5 bg-ink-900/30 py-24 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-6">
        <SectionHeading eyebrow="Voices" title="What the family" accent="says." align="center" />
        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {QUOTES.map((q, i) => (
            <Reveal key={q.name} delay={i * 130}>
              <figure className="group relative flex h-full flex-col border border-ivory-100/10 bg-ink-950/70 p-8 transition-all duration-500 hover:-translate-y-1.5 hover:border-gold-500/35">
                <span className="font-display text-7xl leading-none text-gold-500/40 transition-colors duration-500 group-hover:text-gold-400">
                  &ldquo;
                </span>
                <blockquote className="-mt-6 flex-1 font-display text-[1.28rem] font-medium italic leading-relaxed text-ivory-100">
                  {q.text}
                </blockquote>
                <figcaption className="mt-7 border-t border-ivory-100/8 pt-5">
                  <p className="text-[12.5px] font-semibold uppercase tracking-[0.2em] text-gold-300">
                    {q.name}
                  </p>
                  <p className="mt-1 text-[11px] font-light uppercase tracking-[0.18em] text-ivory-700">
                    {q.role}
                  </p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ================================= CTA band ================================= */

export function CTABand() {
  return (
    <section className="relative overflow-hidden border-y border-gold-500/20">
      <img
        src="images/assembly.jpg"
        alt=""
        aria-hidden="true"
        className="kenburns-slow absolute inset-0 h-full w-full object-cover opacity-25"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-ink-950 via-ink-950/80 to-ink-950" />
      <div className="relative mx-auto max-w-4xl px-5 py-24 text-center sm:py-28">
        <Reveal>
          <Ornament />
        </Reveal>
        <Reveal delay={120}>
          <h2 className="mt-8 font-display text-4xl font-medium leading-[1.08] text-ivory-50 sm:text-6xl">
            The gates on Delhi Road
            <br />
            <em className="italic text-gold-300">stand open.</em>
          </h2>
        </Reveal>
        <Reveal delay={240}>
          <p className="mx-auto mt-6 max-w-xl text-[15px] font-light leading-relaxed text-ivory-300">
            Bring your child for a morning walk through the campus. See the assembly, meet the
            teachers, and let Alwar&rsquo;s oldest tradition of learning speak for itself.
          </p>
        </Reveal>
        <Reveal delay={360}>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <a
              href="#admissions"
              className="btn-sheen group inline-flex items-center gap-3 bg-gold-500 px-8 py-4 text-[11.5px] font-semibold uppercase tracking-[0.24em] text-ink-950 transition-colors duration-300 hover:bg-gold-400"
            >
              Begin Admission 2026–27
              <IconArrow className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </a>
            <a
              href="tel:+911442372479"
              className="inline-flex items-center gap-3 border border-ivory-100/25 px-8 py-4 text-[11.5px] font-semibold uppercase tracking-[0.24em] text-ivory-100 transition-all duration-300 hover:border-gold-400 hover:text-gold-300"
            >
              <IconPhone className="h-4 w-4" />
              0144-2372479
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ================================== Footer ================================== */

const FOOT_LINKS = {
  "Explore": [
    ["Our Legacy", "#legacy"],
    ["Principal's Desk", "#principal"],
    ["Academics", "#academics"],
    ["Campus Life", "#campus"],
    ["Notice Board", "#news"],
  ],
  "Admissions": [
    ["Apply for 2026–27", "#admissions"],
    ["Age Eligibility", "#admissions"],
    ["Documents Required", "#admissions"],
    ["Request Prospectus", "#admissions"],
  ],
};

export function Footer() {
  return (
    <footer id="contact" className="relative overflow-hidden bg-ink-950 pt-20">
      <div className="beam left-1/2 top-0 h-[300px] w-[600px] -translate-x-1/2" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-6">
        <div className="grid gap-12 pb-16 lg:grid-cols-[1.3fr_0.8fr_0.8fr_1.1fr]">
          {/* brand */}
          <div>
            <a href="#top" className="flex items-center gap-4">
              <Crest className="h-14 w-12 text-gold-400" />
              <span className="leading-none">
                <span className="block font-display text-2xl font-semibold text-ivory-50">
                  St. Anselm&rsquo;s
                </span>
                <span className="mt-1.5 block text-[9.5px] font-medium uppercase tracking-[0.32em] text-gold-500">
                  Senior Secondary School
                </span>
              </span>
            </a>
            <p className="mt-6 max-w-sm text-[13.5px] font-light leading-relaxed text-ivory-500">
              A CBSE-affiliated, English-medium, co-educational school of the Gyan Deep Education
              Society — nurturing intellect, faith and character in Alwar since 1987.
            </p>
            <p className="mt-6 text-[10px] font-medium uppercase tracking-[0.34em] text-ivory-700">
              Faith <span className="text-gold-600">◆</span> Knowledge{" "}
              <span className="text-gold-600">◆</span> Character
            </p>
          </div>

          {/* link columns */}
          {Object.entries(FOOT_LINKS).map(([heading, links]) => (
            <nav key={heading} aria-label={heading}>
              <p className="text-[10.5px] font-semibold uppercase tracking-[0.34em] text-gold-400">
                {heading}
              </p>
              <ul className="mt-6 space-y-3.5">
                {links.map(([label, href]) => (
                  <li key={label}>
                    <a
                      href={href}
                      className="group inline-flex items-center gap-2.5 text-[13.5px] font-light text-ivory-500 transition-colors duration-300 hover:text-gold-300"
                    >
                      <span className="h-px w-0 bg-gold-400 transition-all duration-300 group-hover:w-4" />
                      {label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          ))}

          {/* contact */}
          <div>
            <p className="text-[10.5px] font-semibold uppercase tracking-[0.34em] text-gold-400">
              Visit Us
            </p>
            <ul className="mt-6 space-y-4 text-[13.5px] font-light leading-relaxed text-ivory-500">
              <li className="flex items-start gap-3.5">
                <IconPin className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" />
                Delhi Road, Alwar – 301 001,
                <br />
                Rajasthan, India
              </li>
              <li className="flex items-center gap-3.5">
                <IconPhone className="h-4 w-4 shrink-0 text-gold-500" />
                <a href="tel:+911442372479" className="transition-colors hover:text-gold-300">
                  0144-2372479
                </a>
              </li>
              <li className="flex items-center gap-3.5">
                <IconMail className="h-4 w-4 shrink-0 text-gold-500" />
                <a
                  href="mailto:office@anselmsalwar.in"
                  className="transition-colors hover:text-gold-300"
                >
                  office@anselmsalwar.in
                </a>
              </li>
              <li className="flex items-start gap-3.5">
                <IconClock className="mt-0.5 h-4 w-4 shrink-0 text-gold-500" />
                Office hours — Mon to Sat,
                <br />
                8:00 a.m. to 2:00 p.m.
              </li>
            </ul>
          </div>
        </div>

        <Ornament className="opacity-60" />

        <div className="flex flex-col items-center justify-between gap-3 py-7 sm:flex-row">
          <p className="text-[10.5px] font-light uppercase tracking-[0.22em] text-ivory-700">
            © 2026 St. Anselm&rsquo;s Sr. Sec. School · Gyan Deep Education Society
          </p>
          <p className="flex items-center gap-2 text-[10.5px] font-light uppercase tracking-[0.22em] text-ivory-700">
            Affiliated to CBSE <IconFlask className="h-3.5 w-3.5 text-gold-600" /> Est. 1987, Alwar
          </p>
        </div>
      </div>
    </footer>
  );
}
